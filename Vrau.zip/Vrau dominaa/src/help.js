const help = (prefix) => {
	return `
╔══✪〘 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐂𝐎𝐄𝐒〙✪══
║
╠ *𝓑𝓞𝓣 𝓥𝓘𝓒𝓣𝓞𝓡* 
╠😎 *3.0*
╠😎 𝐃𝐎𝐍𝐎: 𝗩𝗜𝗖𝗧𝗢𝗥 
╠😎 *wa.me/+5511987529572*
╠😎 𝐒𝐓𝐀𝐓𝐔𝐒: ON
║
╠══✪〘 𝐍𝐎𝐕𝐎𝐒 〙✪══
║
║🐊 *${prefix}animecry*
║⚜️ *${prefix}chentai [premium]*
║⚜️ *${prefix}gcpf [premium]*
║🐊 *${prefix}gay [@]*
║⚜️ *${prefix}packs [premium]*
║⚜️ *${prefix}destrava [premium]*
║⚜️ *${prefix}gpessoa [premium]*
║🐊 *${prefix}wame*
║🐊 *${prefix}spamcall*
║🐊 *${prefix}play (nome da msc)*
║🐊 *${prefix}pub*
║🐊 *${prefix}gglogo*
║
╠══✪〘 𝐌𝐄𝐍𝐔 〙✪══
║
║🐊 *${prefix}figu*
║🐊 *${prefix}toimg*
║🐊 *${prefix}darkjokes (memes aleatórios)*
║🐊 *${prefix}memeindo*
║🐊 *${prefix}tts*
║🐊 *${prefix}lolih [on]*
║🐊 *${prefix}nsfwloli [off]*
║🐊 *${prefix}url2img*
║🐊 *${prefix}leens [na legenda]*
║🐊 *${prefix}wait [na legenda]*
║🐊 *${prefix}setprefix*
║
╠══✪〘 𝐎𝐔𝐓𝐑𝐎𝐒 〙✪══
║
║🐊 *${prefix}linkgp*
║🐊 *${prefix}simih [1/0]*
║🐊 *${prefix}marcar*
║🐊 *${prefix}add [@]*
║🐊 *${prefix}banir [@]*
║🐊 *${prefix}promover [@]*
║🐊 *${prefix}rebaixar*
║🐊 *${prefix}admins*
║🐊 *${prefix}marcar2*
║🐊 *${prefix}bc [texto]* (ele faz uma ™)
║🐊 *${prefix}marcar3*
║🐊 *${prefix}bloqueados*
║🐊 *${prefix}bloquear [@]*
║🐊 *${prefix}desbloquear [@]*
║🐊 *${prefix}limpar*
║🐊 *${prefix}bc [ *texto* ]*
║🐊 *${prefix}bemvindo [1/0]*
║🐊 *${prefix}help1*
║🐊 *${prefix}dono*
║🐊 *${prefix}owner*
║🐊 *${prefix}tts [texto]*
║🐊 *${prefix}setnome*
║🐊 *${prefix}termux*
║🐊 *${prefix}setfoto*
║🐊 *${prefix}grupoinfo*
║🐊 *${prefix}ytmp4*
║🐊 *${prefix}bomdia*
║🐊 *${prefix}boanoite*
║🐊 *${prefix}marcar*
║🐊 *${prefix}marcar2*
║🐊 *${prefix}marcar3*
║
╠══✪〘 𝐈𝐌𝐀𝐆𝐄𝐍𝐒 〙✪══
║
║📷 *${prefix}loli* [off]
║📷 *${prefix}loli1*
║📷 *${prefix}hentai*
║📷 *${prefix}dono*
║📷 *${prefix}porno*
║📷 *${prefix}boanoite*
║📷 *${prefix}bomdia*
║📷 *${prefix}boatarde*
║📷 *${prefix}mia [aleatórias]*
║📷 *${prefix}rize [aleatórias]*
║📷 *${prefix}minato [aleatórias]*
║📷 *${prefix}boruto [aleatórias]*
║📷 *${prefix}hinata [aleatórias]*
║📷 *${prefix}sasuke [aleatórias]*
║📷 *${prefix}sakura [aleatórias]*
║📷 *${prefix}naruto [aleatórias]*
║📷 *${prefix}meme*   
║📷 *${prefix}lofi*
║📷 *${prefix}malkova*
║📷 *${prefix}canal*
║📷 *${prefix}nsfwloli1*
║📷 *${prefix}reislin*
║
╠══✪〘 𝗜𝗡𝗧𝗘𝗟𝗜𝗚𝗘𝗡𝗖𝗜𝗔 〙✪══
║
║🧠 *${prefix}simih 1 (para ativar)*
║🧠 *${prefix}simih 0 (para desativar)*
║ *${prefix}simi (sua mensagem)*
║
╠══✪〘 𝐄𝐌 𝐏𝐑𝐎𝐃𝐔𝐂𝐀𝐎 〙✪══
║
║🔧 *${prefix}*
║🔧 *${prefix}*
║🔧 *${prefix}*
║
╠══✪〘 𝐏𝐑𝐄𝐌𝐈𝐔𝐌 〙✪══
║
║⚜️ *${prefix}dado*
║⚜️ *${prefix}cekvip*
║⚜️ *${prefix}premiumlist*
║⚜️ *${prefix}delete*
║⚜️ *${prefix}modapk*
║⚜️ *${prefix}indo10*
║⚜️ *${prefix}daftarvip [para virar Premium]*
║⚜️ *${prefix}qrcode*
║⚜️ *${prefix}chentai*
║⚜️ *${prefix}gcpf*
║⚜️ *${prefix}packs*
║⚜️ *${prefix}destrava*
║⚜️ *${prefix}gpessoa*
║
╠══✪〘 𝐆𝐑𝐔𝐏𝐎 〙✪══
║
║🌌 *${prefix}banir*
║🌌 *${prefix}leveling [on/off]*
║🌌 *${prefix}level*
║🌌 *${prefix}add*
║🌌 *${prefix}promover*
║🌌 *${prefix}setfoto [na legenda]*
║🌌 *${prefix}setname [texto]*
║🌌 *${prefix}rebaixar*
║🌌 *${prefix}admins*
║🌌 *${prefix}marcar*
║🌌 *${prefix}marcar2*
║🌌 *${prefix}marcar3*
║🌌 *${prefix}bemvindo [1/0]*
║🌌 *${prefix}grupoinfo*
║🌌 *${prefix}bomdia*
║🌌 *${prefix}boatarde*
║🌌 *${prefix}boanoite*
║🌌 *${prefix}setdesc*
║🌌 *${prefix}bug [sua mensagem]*
║
╠══✪〘 𝐄𝐒𝐏𝐄𝐂𝐈𝐅𝐈𝐂𝐎 𝐃𝐎 𝐁𝐎𝐓 〙✪══
║
║🤖 *${prefix}bug [sua mensagem]*
║🤖 *${prefix}dono*
║🤖 *${prefix}ping [ver velocidade do bot]*
║🤖 *${prefix}termux*
║🤖 *${prefix}gay [@]*
║🤖 *${prefix}wame*
║🤖 *${prefix}map (nome)*
║🤖 *${prefix}setppbot (marque uma img)*
║🤖 *${prefix}pinterest (nome)*
║🤖 *${prefix}desligar (so para o dono)*
║🤖 *${prefix}timer*
║
╠══✪〘 𝐌𝐀𝐈𝐒 𝐀𝐋𝐆𝐔𝐍𝐒 〙✪══
║
║🐊 *${prefix}neko*
║🐊 *${prefix}ttp [texto]*
║🐊 *${prefix}testime*
║🐊 *${prefix}tomp3*
║🐊 *${prefix}modoanime [on/off]*
║🐊 *${prefix}modonsfw [on/off]*
║🐊 *${prefix}happymod [jogo/app]*
║🐊 *${prefix}rize*
║🐊 *${prefix}ytsearch*
║🐊 *${prefix}moddroid [jogo/app]*
║🐊 *${prefix}xvideos [titulo]**
║🐊 *${prefix}nomegp*
║🐊 *${prefix}darkjokes (memes aleatórios)*
║🐊 *${prefix}animecry*
║🐊 *${prefix}gay1*
║🐊 *${prefix}next*
║🐊 *${prefix}alerta*
║🐊 *${prefix}belle [img aleatórias]*
║🐊 *${prefix}pronomeneu [texto]*
║🐊 *${prefix}hobby*
║
╠══✪〘 𝐂𝐎𝐌𝐀𝐍𝐃𝐎𝐒 𝐃𝐄 𝐕𝐎𝐙 〙✪══
║
║🔊 *${prefix}oii*
║🔊 *${prefix}bv*
║🔊 *${prefix}tchau*
║🔊 *${prefix}bem*
║🔊 *${prefix}a*
║🔊 *${prefix}fdp*
║🔊 *${prefix}onich*
║🔊 *${prefix}beat1*
║🔊 *${prefix}glub*
║
╠══✪〘 𝐎𝐔𝐓𝐑𝐎𝐒 /𝟐 〙✪══
║
║🐊 *${prefix}antilink [1/0]*
║🐊 *${prefix}brainly [pergunta]*
║🐊 *${prefix}antiracismo [on/off]*
║🐊 *${prefix}setnomebot*
║🐊 *${prefix}meme*
║
╠══✪〘 𝐈𝐍𝐓𝐄𝐑𝐀𝐓𝐈𝐕𝐎𝐒 〙✪══
║
╠══NOTA »
║*Mandar a msg sem o prefixo*
╠════════════════════
║
║🐊 *bah*
║🐊 *ola*
║🐊 *bv*
║🐊 *canta ai bot*
║🐊 *grita*
║🐊 *sexo*
║🐊 *dbz*
║🐊 *mandememe*
║
╠══✪〘 𝓥𝓘𝓒𝓣𝓞𝓡 𝓝𝓞 𝓒𝓞𝓜𝓐𝓝𝓓𝓞 〙✪══
║
║ *NOME: 𝓐𝓓𝓜 𝓥𝓘𝓒𝓣𝓞𝓡*
║ *INSTA: https://www.instagram.com/gamerlagado/*
║ *WPP: wa.me/+55119875295727*
║ *YOUTUBE: https://www.youtube.com/channel/UC5XgXdQO1_T9ChVLgVAiI3A*
║ *𝐒𝐇𝐈𝐓𝐏𝐎𝐒𝐓 𝐄𝐋𝐈𝐓𝐄⚜️: https://chat.whatsapp.com/Eedio1m9BcO6YpY8vDE2p7
║  
║  *"CRINGE MORRE CEDO 🐊👑*
║  
║
║
╚═〘 𝓑𝓞𝓣 𝓥𝓘𝓒𝓣𝓞𝓡 〙`
}

exports.help = help

