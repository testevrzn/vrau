const cekvip = () => { 
	return `           
──────────────────
*Nome do bot* :  𝓑𝓞𝓣 𝓥𝓘𝓒𝓣𝓞𝓡
──────────────────
    『 *𝑼𝑺𝑼𝑨́𝑹𝑰𝑶 𝑽𝑰𝑷⚜️* 』
──────────────────
• *Status*    : *ATIVO*
────────────────── 
• *Status Bot:* *Online*
──────────────────

*VOCE E UM MEMBRO PREMIUM* ⚜️🚩`
}
exports.cekvip = cekvip