const iklan = () => { 
	return `           
╔══✪〘 𝐏𝐑𝐎𝐏𝐀𝐆𝐀𝐍𝐃𝐀 〙✪══
║
╠═══════════════════════════
╠➥ *LISTA DE ALUGUEL E CRIAR BOTS:*
╠➥ *ALUGUEL: 10 / GRUPO (MÊS)*
╠➥ *CRIAR: 35 (PODE SER PROPRIETÁRIO)*
╠➥ *PODE PAGAR ATRAVÉS DE:*
╠➥ *PIX E TRANSFERENCIA,*
╠═══════════════════════════
╠➥ *VANTAGENS*
╠➥ *wa.me/+5511987529572*
║
╚═〘  𝓐𝓓𝓜 𝓥𝓘𝓒𝓣𝓞𝓡  〙
`
}
exports.iklan = iklan